<?php $__env->startSection('page_title', __('voyager::generic.'.(isset($dataTypeContent->id) ? 'edit' : 'add')).' '.$dataType->getTranslatedAttribute('display_name_singular')); ?>

<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <h1 class="page-title">
        <i class="<?php echo e($dataType->icon); ?>"></i>
        <?php echo e(__('voyager::generic.'.(isset($dataTypeContent->id) ? 'edit' : 'add')).' '.$dataType->getTranslatedAttribute('display_name_singular')); ?>

    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <form class="form-edit-add" role="form"
              action="<?php if(!is_null($dataTypeContent->getKey())): ?><?php echo e(route('voyager.'.$dataType->slug.'.update', $dataTypeContent->getKey())); ?><?php else: ?><?php echo e(route('voyager.'.$dataType->slug.'.store')); ?><?php endif; ?>"
              method="POST" enctype="multipart/form-data" autocomplete="off">
            <!-- PUT Method if we are editing -->
            <?php if(isset($dataTypeContent->id)): ?>
                <?php echo e(method_field("PUT")); ?>

            <?php endif; ?>
            <?php echo e(csrf_field()); ?>


            <div class="row">
                <div class="col-md-8">
                    <div class="panel panel-bordered">
                        
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="panel-body">
                            <div class="form-group">
                                <label for="name"><?php echo e(__('voyager::generic.name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name"
                                       placeholder="<?php echo e(__('voyager::generic.name')); ?>"
                                       value="<?php echo e(old('name', $dataTypeContent->name ?? '')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="email"><?php echo e(__('voyager::generic.email')); ?></label>
                                <input type="email" class="form-control" id="email" name="email"
                                       placeholder="<?php echo e(__('voyager::generic.email')); ?>"
                                       value="<?php echo e(old('email', $dataTypeContent->email ?? '')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="password"><?php echo e(__('voyager::generic.password')); ?></label>
                                <?php if(isset($dataTypeContent->password)): ?>
                                    <br>
                                    <small><?php echo e(__('voyager::profile.password_hint')); ?></small>
                                <?php endif; ?>
                                <input type="password" class="form-control" id="password" name="password" value=""
                                       autocomplete="new-password">
                            </div>













                            <?php
                                if (isset($dataTypeContent->locale)) {
                                    $selected_locale = $dataTypeContent->locale;
                                } else {
                                    $selected_locale = config('app.locale', 'en');
                                }

                            ?>
                            <div class="form-group">
                                <label for="locale"><?php echo e(__('voyager::generic.locale')); ?></label>
                                <select class="form-control select2" id="locale" name="locale">
                                    <?php $__currentLoopData = Voyager::getLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($locale); ?>"
                                                <?php echo e(($locale == $selected_locale ? 'selected' : '')); ?>><?php echo e($locale); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="phone"
                                       value="<?php echo e(old('phone', $dataTypeContent->phone ?? '')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="phone_verified">Phone Verification</label>
                                <select class="form-control select2" id="phone_verified" name="phone_verified">
                                    <option value="0" <?php echo e(($dataTypeContent->phone_verified == 0 ? 'selected' : '')); ?> >
                                        No
                                    </option>
                                    <option value="1" <?php echo e(($dataTypeContent->phone_verified == 1 ? 'selected' : '')); ?>>
                                        Yes
                                    </option>
                                </select>
                            </div>


                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address"
                                       placeholder="Address"
                                       value="<?php echo e(old('address', $dataTypeContent->address ?? '')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="type">Type</label>

                                <select class="form-control select2" id="type" name="type">
                                    <option value="user" <?php echo e(($dataTypeContent->type == 'user' ? 'selected' : '')); ?> >
                                        User
                                    </option>
                                    <option value="dealer" <?php echo e(($dataTypeContent->type == 'dealer' ? 'selected' : '')); ?>>
                                        Dealer
                                    </option>
                                </select>
                            </div>




                            <div class="form-group">
                                <label for="points">Points</label>
                                <input type="text" class="form-control" id="points" name="point" placeholder="Points"
                                       value="<?php echo e(old('point', $dataTypeContent->point ?? '')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="approve">Approval</label>
                                <select class="form-control select2" id="approve" name="approve">
                                    <option value="0" <?php echo e(($dataTypeContent->approve == 0 ? 'selected' : '')); ?> > Not
                                        approved
                                    </option>
                                    <option value="1" <?php echo e(($dataTypeContent->approve == 1 ? 'selected' : '')); ?>>
                                        Approved
                                    </option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="login">Login</label>
                                <select class="form-control select2" id="login" name="login">
                                    <option value="0" <?php echo e(($dataTypeContent->login == 0 ? 'selected' : '')); ?> > Not
                                        Logged in
                                    </option>
                                    <option value="1" <?php echo e(($dataTypeContent->login == 1 ? 'selected' : '')); ?>> Logged
                                        in
                                    </option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="trusted">Trusted User ?</label>
                                <select class="form-control select2" id="trusted" name="trusted">
                                    <option value="0" <?php echo e(($dataTypeContent->trusted == 0 ? 'selected' : '')); ?> > Not
                                        Trusted
                                    </option>
                                    <option value="1" <?php echo e(($dataTypeContent->trusted == 1 ? 'selected' : '')); ?>>
                                        Trusted
                                    </option>
                                </select>
                            </div>


                            <div class="form-group">
                                <label for="valid_to">Valid to</label>
                                <input type="date" class="form-control" id="valid_to" name="valid_to"
                                       placeholder="Valid to"
                                       value="<?php echo e(old('valid_to', $dataTypeContent->valid_to ?? '')); ?>">
                            </div>

                        </div>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="panel panel panel-bordered panel-warning">
                        <div class="panel-body">
                            <div class="form-group">
                                <?php if(isset($dataTypeContent->avatar)): ?>
                                    <img src="<?php echo e(filter_var($dataTypeContent->avatar, FILTER_VALIDATE_URL) ? $dataTypeContent->avatar : Voyager::image( $dataTypeContent->avatar )); ?>"
                                         style="width:200px; height:auto; clear:both; display:block; padding:2px; border:1px solid #ddd; margin-bottom:10px;"/>
                                <?php endif; ?>
                                <input type="file" data-name="avatar" name="avatar">
                            </div>


                        </div>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="panel panel panel-bordered panel-warning">
                        <div class="panel-body">


                            <h4>Social Login details</h4>
                            <div class="form-group">
                                <label for="provider">Provider</label>
                                <input type="text" class="form-control" id="provider" name="provider"
                                       placeholder="Provider"
                                       value="<?php echo e(old('provider', $dataTypeContent->provider ?? '')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="provider_id">Provider ID</label>
                                <input type="text" class="form-control" id="provider_id" name="provider_id"
                                       placeholder="Provider ID"
                                       value="<?php echo e(old('provider_id', $dataTypeContent->provider_id ?? '')); ?>">
                            </div>
                        </div>
                    </div>
                </div>


            </div>

            <button type="submit" class="btn btn-primary pull-right save">
                <?php echo e(__('voyager::generic.save')); ?>

            </button>
        </form>

        <iframe id="form_target" name="form_target" style="display:none"></iframe>
        <form id="my_form" action="<?php echo e(route('voyager.upload')); ?>" target="form_target" method="post"
              enctype="multipart/form-data" style="width:0px;height:0;overflow:hidden">
            <?php echo e(csrf_field()); ?>

            <input name="image" id="upload_file" type="file" onchange="$('#my_form').submit();this.value='';">
            <input type="hidden" name="type_slug" id="type_slug" value="<?php echo e($dataType->slug); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $('document').ready(function () {
            $('.toggleswitch').bootstrapToggle();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/procodex/public_html/original/resources/views/vendor/voyager/users/edit-add.blade.php ENDPATH**/ ?>