<?php $__env->startSection('content'); ?>

    <div class="login-screen">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="logo-log-side">
                        <img src="<?php echo e(asset('dash/images/logo.png')); ?>">
                    </div>
                    <div class="fields-login-side">
                        <div class="upp-login">
                            <h5>تسجيل الدخول</h5>
                            <p>قم بأدخال اسم المستخدم وكلمة المرور</p>
                        </div>

                        <div class="field-input-login-side">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if($errors->any()): ?>
                                    <?php echo e(implode('', $errors->all(`<div>:message</div>`))); ?>

                                <?php endif; ?>
                                <div class="form_field">
                                    <input type="text" name="phone"
                                           class="form_input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="الهاتف" value="<?php echo e(old('phone')); ?>" required
                                           autocomplete="phone" autofocus>
                                    <label for="phone" class="form_label">الهاتف</label>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form_field">
                                    <input id="password" name="password" type="password"
                                           class="form_input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="كلمة المرور" required autocomplete="current-password">
                                    <label for="password" class="form_label">كلمة المرور</label>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="remember-pass">
                                            <input class="form-check-input" type="checkbox" name="remember"
                                                   id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label for="remember">تذكر كلمة المرور</label>
                                        </div>


                                    </div>











                                </div>
                                <input type="submit" class="form_button" value="تسجيل دخول">


                            </form>

                            <div class="login-social">
                                <div class="or">
                                    <span>أو</span>
                                </div>
                                <ul>
                                    <a href="">
                                        <li>
                                            <img src="<?php echo e(asset('dash/images/facebook-ic.png')); ?>" alt="">
                                        </li>
                                    </a>
                                    <a href="">
                                        <li>
                                            <img src="<?php echo e(asset('dash/images/twitter-ic.png')); ?>" alt="">
                                        </li>
                                    </a>
                                    <a href="">
                                        <li>
                                            <img src="<?php echo e(asset('dash/images/google-ic.png')); ?>" alt="">
                                        </li>
                                    </a>
                                </ul>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="car-login-side">
                        <div class="car-primary-img-login">
                            <img src="<?php echo e(asset('dash/images/hold-mob.png')); ?>">
                            <div class="caro-txt">
                                <h6>أهلا وسهلا بك</h6>
                                <p>مع خدمة البحث يمكنك إيجاد ما ترغب به</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/auth/login.blade.php ENDPATH**/ ?>