 <div class="col-md-4" style="padding: 0;">
                                <div class="account-details-column" style="height: 100%;">
                                    <h6>تفاصيل الحساب</h6>
                                    <ul>
                                        <a href="<?php echo e(route('settings')); ?>">
                                            <li class="<?php if(\Route::currentRouteName()=='settings'): ?> liactive <?php endif; ?>"><i class="fas fa-user"></i> تفاصيل الحساب </li>
                                        </a>
                                        <a href="<?php echo e(route('store-details')); ?>" >
                                            <li class="<?php if(\Route::currentRouteName()=='store-details'): ?> liactive <?php endif; ?>"><i class="fas fa-store"></i> تفاصيل المتجر </li>
                                        </a>
                                        <a href="<?php echo e(route('dealer-cars')); ?>">
                                            <li class="<?php if(\Route::currentRouteName()=='dealer-cars'): ?> liactive <?php endif; ?>"> <i class="fas fa-car"></i> تفاصيل السيارات </li>
                                        </a>
                                        <a href="<?php echo e(route('get-contact')); ?>">
                                            <li class="<?php if(\Route::currentRouteName()=='get-contact'): ?> liactive <?php endif; ?>" ><i class="fas fa-headset"></i> الدعم الفني </li>
                                        </a>
                                        <a href="">
                                            <li ><i class="fas fa-headset"></i> تقيمات المتجر </li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
<?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/includes/settings-menu.blade.php ENDPATH**/ ?>