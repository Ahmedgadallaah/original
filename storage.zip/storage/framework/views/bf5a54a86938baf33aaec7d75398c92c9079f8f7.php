<?php $__env->startSection('content'); ?>
    <div class="content-all">
        <?php echo $__env->make('dashboard.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-inner">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="bannner-apps">
                                <div class="apps-show-banner">
                                    <h5>قم بالترقية الأن</h5>
                                    <p>قم بترقية حسابك حتي تتمكن من التمتع بميزات تساعدك في تحسين
                                        عملية البيع والوصول لعدد أكبر من المستخدمين</p>
                                    <a href=""><img src="images/tarqia-app.png"></a>
                                </div>
                            </div>

                            <div class="sec-sec-row">
                                <div class="title-box-chart">
                                    <h5>المخزون</h5>
                                </div>
                                
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-md-2">
                                            <div class="product-percen-sub">
                                                <div class="chart" data-percent="25" data-scale-color="#EE504F">
                                                    <span> <strong><?php echo e($category->products->count()); ?></strong> <br> قطعة </span>
                                                </div>
                                                <div>
                                                    <small><?php echo e($category->getTranslatedAttribute('name' , 'ar')); ?></small>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>

                                </div>
                            </div>
                            <br>
                            <div class="action-play product-action-play">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="title-box-chart">
                                            <h5>المنتجات</h5>
                                                   <div class="product-divs" style="text-align: right !important;">
                                                    <a href="<?php echo e(route('createDealerProducts')); ?>" class="add-prod"> <i
                                                            class="fas fa-plus"></i> أضف منتج
                                                        </a>
                                                </div>
                                        </div>
                                    </div>


                                    <div class="col-md-12">
                                        <div class="parts-sec-all products-parts-sec-all">

                                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="parts-contect-sec">
                                                <div class="row">
                                                    <div class="col-md-5">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="prod-img-parts">
                                                                    <img src="<?php echo e(Storage::url($product->image)); ?>" width="100%">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <div class="prod-txts-parts">
                                                                    <h6> <?php echo e($product->name); ?> </h6>
                                                                    <span>
                                                                        الكمية :
                                                                        <?php echo e($product->quantity); ?>

                                                                        قطع
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div>
                                                                    <small style="color: #59626B; font-size: 12px;">
                                                                            السيارة :
                                                                     <?php echo e($product->car->name_ar??'غير معروف'); ?>

                                                                    </small>
                                                                </div>
                                                                <div>
                                                                    <small style="color: #EE504F;">

                                                                السعر :        <?php echo e($product->price??'غير معروف'); ?> جنية
                                                                    </small>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="row">
                                                            <div class="col-md-9">
                                                                <div style="text-align: left;">
                                                                    <?php $__empty_2 = true; $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                          <img src="<?php echo e(url('/').Storage::url($img)); ?>" width="32">
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                    <?php endif; ?>

                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="product-divs">
                                                                    <div class="dropdown">
                                                                        <button class="btn btn-secondary" type="button"
                                                                            id="dropdownMenuButton1"
                                                                            data-bs-toggle="dropdown" aria-expanded="false">
                                                                            <small><i class="fas fa-ellipsis-v"></i></small>
                                                                        </button>
                                                                        <ul class="dropdown-menu"
                                                                            aria-labelledby="dropdownMenuButton1">
                                                                            <li><a class="dropdown-item"
                                                                                    href="<?php echo e(route('editDealerProducts' , $product->id)); ?>">تعديل</a></li>

                                                                            <li><a class="dropdown-item" href="<?php echo e(route('deleteProducts' , $product->id)); ?>">
                                                                             مسح
                                                                                </a>
                                                                                </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p> لا يوجد لديك منتجات </p>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                                    <?php echo $__env->make('dashboard.layouts.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/products/products.blade.php ENDPATH**/ ?>