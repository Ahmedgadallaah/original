<?php $__env->startSection('content'); ?>
<div class="content-all">
    <?php echo $__env->make('dashboard.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-inner">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <!-- ****************************** Middle-All ****************************** -->
                    <div class="col-md-8">
                        <div class="row">
                            <?php echo $__env->make('dashboard.includes.settings-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="col-md-8">
                                <div class="bannner-apps">
                                    <div class="apps-show-banner">
                                        <h5>قم بالترقية الأن</h5>
                                        <p style="font-size: 10px;">قم بترقية حسابك حتي تتمكن من التمتع بميزات تساعدك في
                                            تحسين
                                            عملية البيع والوصول لعدد أكبر من المستخدمين</p>
                                        <a href=""><img src="images/tarqia-app.png"></a>
                                    </div>
                                </div>
                                <div class="right-message-details">
                                    <h6>أنواع السيارات</h6>
                                    <p style="width: 80%;">أختيارك لانواع السيارات التي تعمل بها يسهل الوصول لمنتجاتك
                                        ويزيد من أرباحك </p>

                                        <div class="parts-sec-all products-parts-sec-all">

                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img  src="<?php echo e(Storage::disk('public')->url($car->mark->image)); ?>" width="100%" style="border: 0;">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">

                                                                <h6>الماركة : <?php echo e($car->mark->getTranslatedAttribute('name')); ?>

                                                                    السنة :<?php echo e($car['year']['year']); ?> <br> المحرك : <?php echo e($car['engine']->getTranslatedAttribute('name')); ?>

                                                                </h6>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div style="text-align: left; padding-top: 7px;">
                                                        <form action="<?php echo e(route('delete-car')); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" value="<?php echo e($car->id); ?>" name="id">
                                                        <button type="submit" style="text-decoration: none;color:#ee504f; border-radius:50%;background-color:#fff;border:2px solid #ee504f"><strong>-</strong></button>
                                                        </form>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <div class="add-car">
                                            <a href="<?php echo e(route('add-car')); ?>"> <button class="form-control"> <i
                                                        class="fas fa-plus"></i> أضافة سيارة </button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('dashboard.layouts.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/car-details.blade.php ENDPATH**/ ?>