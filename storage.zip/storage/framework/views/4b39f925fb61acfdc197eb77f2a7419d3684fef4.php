      <div class="fixed-menu">
            <i class="fas fa-angle-left"></i>
            <div class="fixed-menu-padd">
                <ul>
                    <li class="<?php if(\Route::currentRouteName()=='index'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('index')); ?>"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='settings'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('settings')); ?>"><i class="fas fa-cog"></i> الأعدادات</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='dealerProducts'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('dealerProducts')); ?>"><i class="fas fa-sign-out-alt"></i> منتجاتي</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='buy-orders'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('buy-orders')); ?>"><i class="fas fa-sign-out-alt"></i> طلبات الشراء</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='dealerSales'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('dealerSales')); ?>"><i class="fas fa-sign-out-alt"></i> مبيعاتي</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='part-request'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('part-request')); ?>"><i class="fas fa-sign-out-alt"></i> طلبات القطع</a></li>
                    <li class="<?php if(\Route::currentRouteName()=='chat'): ?> liactive <?php endif; ?>"><a href="<?php echo e(route('chat')); ?>"><i class="fas fa-comment-alt"></i> الرسايل</a></li>
                    <li><a href="index.html"><i class="fas fa-sign-out-alt"></i> تسجيل خروج</a></li>
                </ul>
            </div>
            <div class="right-side in-fixed-menu">
                <div class="bg-tarqia side-problem">
                    <h6>هل تواجه مشكلة ؟</h6>

                    <p>إذا واجهتك مشكلة فيسعدنا تواصلك
                        معانا من خلال هذا الرابط </p>
                    <button><a href="" data-bs-toggle="modal" data-bs-target="#Terms-Conditions">تواصل
                            معانا</a></button>
                </div>
            </div>
        </div>
<?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/includes/side-menu.blade.php ENDPATH**/ ?>