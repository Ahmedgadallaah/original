<div>
    <div class="form-grid">
        <label for=""><small>ماركة السيارة</small></label>
        <select name="mark_id" id="slick" wire:model="mark" required>
          <option  selected>اختر</option>
            <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mark->id); ?>" data-description='' style="color:#000;"> <?php echo e($mark->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <option value="1" data-description='' data-imagesrc="images/car-type.png"> تويوتا </option>
        </select>
    </div>
    <div class="form-grid">
        <label for=""><small>فئة السيارة</small></label>
        <select name="model_id" id="" required wire:model="model">
            <option  selected>اختر</option>
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($model->id); ?>" data-description='' style="color:#000;"> <?php echo e($model->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-grid">
        <label for=""><small>نوع المحرك</small></label>
        <select name="engine_id" id="" required>
            <option disabled selected>اختر</option>
            <?php $__currentLoopData = $engines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($engine->id); ?>" data-description='' style="color:#000;"> <?php echo e($engine->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-grid">
        <label for=""><small>سنة التصنيع</small></label>
        <select name="year_id" id="" required>
            <option disabled selected>اختر</option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>" data-description='' style="color:#000;"> <?php echo e($year->year); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/livewire/add-car.blade.php ENDPATH**/ ?>