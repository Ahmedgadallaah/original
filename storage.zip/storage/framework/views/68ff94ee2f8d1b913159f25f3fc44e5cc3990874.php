<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Original</title>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('dash/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dash/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="<?php echo e(@asset('toastr/toastr.min.css')); ?>" rel="stylesheet" >
     <?php echo \Livewire\Livewire::styles(); ?>


</head>
<?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/layouts/header.blade.php ENDPATH**/ ?>