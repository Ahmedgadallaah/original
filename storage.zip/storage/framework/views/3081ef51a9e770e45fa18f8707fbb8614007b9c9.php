<!DOCTYPE HTML>

<html lang="en">
<?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body style="background-color: #F3F7FA;">
    <?php echo $__env->make('dashboard.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script type="module">
        // Import the functions you need from the SDKs you need
        import {
            initializeApp
        } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
        import {
            getAnalytics
        } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-analytics.js";
        // TODO: Add SDKs for Firebase products that you want to use
        // https://firebase.google.com/docs/web/setup#available-libraries

        // Your web app's Firebase configuration
        // For Firebase JS SDK v7.20.0 and later, measurementId is optional
        const firebaseConfig = {
            apiKey: "AIzaSyDk1vIQhFxTc5WuOT6ojmWekkpNA8iulEM",
            authDomain: "original-customer.firebaseapp.com",
            projectId: "original-customer",
            storageBucket: "original-customer.appspot.com",
            messagingSenderId: "161494308415",
            appId: "1:161494308415:web:41535ebbfb15dc68af4a8a",
            measurementId: "G-T2GGGQCWPM"
        };

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);
        const analytics = getAnalytics(app);
    </script>
</body>

</html>
<?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/layouts/app.blade.php ENDPATH**/ ?>