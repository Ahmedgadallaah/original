<?php $__env->startSection('content'); ?>
<div class="content-all">
    <?php echo $__env->make('dashboard.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-inner">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <!-- ****************************** Middle-All ****************************** -->
                    <div class="col-md-8">
                          <div class="row">
                            <?php echo $__env->make('dashboard.includes.settings-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="col-md-8">
                                <div class="add-product-title">
                                    <h6><a href="Message.html"><img src="images/back-ic.png" width="25" alt=""></a> الرجوع أنواع السيارات </h6>
                                </div>
                                <div class="form-add-finial add-car-screen">

                                    <h6>أضافة سيارة جديده</h6>
                                    <br>
                                    <form action="<?php echo e(route('store-car')); ?>" method="post" >
                                        <?php echo csrf_field(); ?>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-car')->html();
} elseif ($_instance->childHasBeenRendered('hDJBKDU')) {
    $componentId = $_instance->getRenderedChildComponentId('hDJBKDU');
    $componentTag = $_instance->getRenderedChildComponentTagName('hDJBKDU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hDJBKDU');
} else {
    $response = \Livewire\Livewire::mount('add-car');
    $html = $response->html();
    $_instance->logRenderedChild('hDJBKDU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <button class="btn btn-primaryC" type="submit">
                                                إضف السيارة
                                            </button>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                          </div>
                        </div>
                    <?php echo $__env->make('dashboard.layouts.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/add-car.blade.php ENDPATH**/ ?>