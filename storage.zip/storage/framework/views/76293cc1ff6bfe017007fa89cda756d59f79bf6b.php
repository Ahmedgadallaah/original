<?php $__env->startSection('content'); ?>
    <div class="content-all">
        <?php echo $__env->make('dashboard.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-inner">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <!-- ****************************** Middle-All ****************************** -->
                        <div class="col-md-8">

                            <div class="sec-sec-row">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="thre-sec">
                                            <div>
                                                <h6>المتاح فى المخزن</h6>
                                                <p><b><strong><?php echo e($totalInStock); ?></strong></b></p>
                                                <p>قطعة</p>
                                            </div>
                                            <div>
                                                <h6>القطع المباعة</h6>
                                                <p><b><strong><?php echo e($totalSellQty); ?></strong> </b></p>
                                                <p>قطعة</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="chart-bg">
                                            <div class="title-box-chart">
                                                <h5>مبيعات المنتجات</h5>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6><b><Strong><?php echo e($totalSales); ?></Strong></b> ج.م</h6>
                                                    <span><small
                                                            style="font-size: 10px; display: block; margin-top: -10px;">أجمالي الربح</small></span>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-4"></div>
                                                        <div class="col-md-4">
                                                            <div>
                                                                <div class="dropdown">
                                                                    <button class="btn btn-secondary dropdown-toggle"
                                                                            type="button" id="dropdownMenuButton1"
                                                                            data-bs-toggle="dropdown"
                                                                            aria-expanded="false"
                                                                            style="background-color: rgba(118,185,82,.2); border: none; color: #76B952;">
                                                                        21%
                                                                    </button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div style="padding-right: 15px;">
                                                                <div class="dropdown">
                                                                    <button class="btn btn-secondary dropdown-toggle"
                                                                            type="button" id="dropdownMenuButton1"
                                                                            data-bs-toggle="dropdown"
                                                                            aria-expanded="false"
                                                                            style="background-color: rgba(238,80,79,.2); border: none; color: #EE504F;">
                                                                        42%
                                                                    </button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <canvas id="myChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <div class="action-play product-action-play">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="title-box-chart">
                                            <h6>طلبات الشراء</h6>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="product-divs">

                                                    <form>
                                                        <input value="<?php echo e(request()->search); ?>" name="search"
                                                               type="text"> <i class="fa fa-search"></i>
                                                    </form>

                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="parts-sec-all products-parts-sec-all">

                                            <?php $__empty_1 = true; $__currentLoopData = $totalItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="parts-contect-sec">
                                                    <div class="row">
                                                        <div class="col-md-5">
                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <div class="prod-img-parts">
                                                                        <img
                                                                            src="<?php echo e(Storage::disk('public')->url($item->product->image??'')); ?>"
                                                                            width="100%">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-8">
                                                                    <div class="prod-txts-parts">
                                                                        <h6> <?php echo e($item->product_name); ?> </h6>
                                                                        <span> الكمية المطلوبة <b><?php echo e($item->product_qty); ?></b> قطعة </span>
                                                                        <span> <i class="fas fa-clock"></i> <?php echo e($item->created_at->format('l j F Y')); ?>  </span>
                                                                        <span> <i class="fas fa-wallet"></i> الدفع عن الاستلام  </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div>
                                                                        <small style="color: #59626B; font-size: 12px;">
                                                                            اسم المشتري
                                                                            : <?php echo e($item->order->user->name??''); ?>

                                                                        </small>
                                                                        <br>
                                                                        <small style="color: #59626B; font-size: 12px;">
                                                                            الهاتف : <?php echo e($item->order->user->phone??''); ?>

                                                                        </small>
                                                                    </div>
                                                                    <div>
                                                                        السعر :
                                                                        <small
                                                                            style="color: #EE504F;"><?php echo e($item->product_total); ?>

                                                                            جم
                                                                            
                                                                        </small>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="row" style="text-align: left;">
                                                                <div class="col-md-9">
                                                                    <div class="text-left">
                                                                        <a href="" class="see" data-bs-toggle="modal"
                                                                           data-id="<?php echo e($item->id); ?>"
                                                                           data-bs-target="#exampleModal-<?php echo e($item->id); ?>">
                                                                            <img
                                                                                src="<?php echo e(asset('dash/images/see-ic.png')); ?>"
                                                                                width="25"></a>

                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="modal fade" id="exampleModal-<?php echo e($item->id); ?>" tabindex="-1"
                                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" style="max-width: 70% !important;">
                                                        <div class="modal-content"
                                                             style="background: none; border: none;">
                                                            <div class="modal-body" id="item-data">
                                                                <div class="add-product-form">
                                                                    <div class="row">
                                                                        <div class="col-md-8">
                                                                            <div class="form-add-prod-sub">
                                                                                <div class="row">
                                                                                    <div class="col-md-4">
                                                                                        <div class="prod-img-parts">
                                                                                            <img
                                                                                                src="<?php echo e(Storage::disk('public')->url($item->product->image??'')); ?>"
                                                                                                width="70%">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-md-8">
                                                                                        <div class="prod-txts-parts">
                                                                                            <h6> <?php echo e($item->product_name); ?> </h6>
                                                                                            <span> <i
                                                                                                    class="fas fa-clock"></i> <?php echo e($item->created_at->format('l j F Y')); ?>  </span>
                                                                                            <div>
                                                                                                <small
                                                                                                    style="color: #EE504F;">
                                                                                                    <?php echo e($item->product_total); ?>

                                                                                                    جم
                                                                                                    
                                                                                                </small>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="parts-sec-all products-parts-sec-all">
                                                                                    <div class="info-details">
                                                                                        <h6>حالة الطلب : ناجحة</h6>
                                                                                        <div class="details-sub">
                                                                                            <span>صاحب الطلب</span>
                                                                                            <h6><?php echo e($item->order->user->name??''); ?></h6>
                                                                                        </div>
                                                                                        <div class="details-sub">
                                                                                            <span>رقم التيلفون</span>
                                                                                            <h6><?php echo e($item->order->user->phone??''); ?></h6>
                                                                                        </div>
                                                                                        <div class="details-sub">
                                                                                            <span>وسيلة الدفع</span>
                                                                                            <h6>الدفع عند الاستلام</h6>
                                                                                        </div>
                                                                                        <div class="details-sub">
                                                                                            <span>العنوان</span>
                                                                                            <h6><?php echo e($item->order->user->address??''); ?></h6>
                                                                                        </div>
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                    </div>
                                                                                </div>

                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-4">
                                                                            <div class="add-prod-right-sub">
                                                                                <div class="sub-img">
                                                                                    <img
                                                                                        src="images/add-prod-subImg.png"
                                                                                        alt="">
                                                                                </div>
                                                                                <div class="list-sub">
                                                                                    <h6>معلومات تهمك</h6>
                                                                                    <span>
                              <span class="number-sub"> 1 </span>
                              إحرص  علي تسليم القطعة في إسرع وقت لكسب
                              ثقة العميل
                          </span>
                                                                                    <span>
                              <span class="number-sub"> 2 </span>
                           إحرص علي التواصل مع العميل من خلال الرسائل في حالة الأستلام
                          </span>
                                                                                    <span>
                              <span class="number-sub"> 3 </span>
                              إذا واجعتك مشكلة تواصل معانا في أي وقت فنحن هنا من أجلك
                          </span>
                                                                                    <span>
                              <span class="number-sub"> 4 </span>
                              تابع مخزون القطع إول بأول لعدم وقم بالتأكدمن وجود القطع فى متجرك
                          </span>
                                                                                    <span>
                              <span class="number-sub"> 5 </span>
                               قم بفحص القطعة جيداً قبل تسليمه وتأكد انها مطابقة ولا يوجد بها مشاكل
                          </span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <div class="parts-contect-sec">
                                                    ليس لديك مبيعات
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ****************************** Right Side ****************************** -->
                           <?php echo $__env->make('dashboard.layouts.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>

     <script>
            let myChart = document.getElementById('myChart').getContext('2d');
            let massPopChart = new Chart(myChart, {
                type:'bar',
                data:{
                    labels:['السبت', 'الحد', 'الاثنين', 'الثلاثاء', 'الاربعاء', 'الخميس', 'الجمعة', 'السبت'],
                    datasets:[{
                        label:'Population',
                        data:[
                            453060,
                            251045,
                            617594,
                            286519,
                            405162,
                            305162,
                            555162,
                            95072
                        ],
                        backgroundColor:'#EE504F',
                        borderWidth:1,
                        borderColor:'#fff',
                        hoverBorderWidth:2,
                        hoverBorderColor:'#fff'
                    }]
                },
                option:{
                    legend:{
                        display:false,
                    }
                }
            });
        </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/don-tair/New Volume1/work/original/resources/views/dashboard/sales.blade.php ENDPATH**/ ?>