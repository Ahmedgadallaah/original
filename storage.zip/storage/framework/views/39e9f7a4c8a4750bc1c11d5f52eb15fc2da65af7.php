
<?php $__env->startSection('content'); ?>
<div class="content-all">
    <div class="fixed-menu">
        <i class="fas fa-angle-left"></i>
        <div class="fixed-menu-padd">
            <ul>
                <li class="liactive"><a href="home.html"><i class="fas fa-home"></i> الرئيسية</a></li>
                <li><a href="Message.html"><i class="fas fa-comment-alt"></i> الرسايل</a></li>
                <li><a href="Products.html"><i class="fas fa-sign-out-alt"></i> منتجاتي</a></li>
                <li><a href="buyRequests.html"><i class="fas fa-sign-out-alt"></i> طلبات الشراء</a></li>
                <li><a href="my-Sales.html"><i class="fas fa-sign-out-alt"></i> مبيعاتي</a></li>
                <li><a href="#"><i class="fas fa-sign-out-alt"></i> طلبات القطع</a></li>
                <li><a href="setting.html"><i class="fas fa-cog"></i> الأعدادات</a></li>
                <li><a href="index.html"><i class="fas fa-sign-out-alt"></i> تسجيل خروج</a></li>
            </ul>
        </div>
        <div class="right-side in-fixed-menu">
            <div class="bg-tarqia side-problem">
                <h6>هل تواجه مشكلة ؟</h6>
                <p>إذا واجهتك مشكلة فيسعدنا تواصلك
                    معانا من خلال هذا الرابط </p>
                <button><a href="" data-bs-toggle="modal" data-bs-target="#Terms-Conditions">تواصل
                        معانا</a></button>
            </div>
        </div>
    </div>

    <div class="content-inner">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <!-- ****************************** Middle-All ****************************** -->
                    <div class="col-md-8">
                        <div class="bannner-apps">
                            <div class="apps-show-banner">
                                <h5>قم بإدارة متجرك في أي مكان</h5>
                                <p>فم بإدارة أعمالك ومتجرك من أي مكان من خلال تطبيق التاجر الذي
                                    يساعدك في ذلك <span>حمل التطبيق الأن</span></p>
                                <a href=""><img src="images/app-store.png"></a>
                                <a href=""><img src="images/play-store.png"></a>
                            </div>
                        </div>

                        <div class="sec-sec-row">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="thre-sec">
                                        <div>
                                            <h6>إجمالي ربح اليوم</h6>
                                            <p><b><strong>1450</strong></b> ج.م</p>
                                        </div>
                                        <div>
                                            <h6>إجمالي مبيعات اليوم</h6>
                                            <p><b><strong>800</strong> </b> قطعة</p>
                                        </div>
                                        <div>
                                            <h6>تقييم العملاء</h6>
                                            <img src="images/star.png" alt="">
                                            <img src="images/star.png" alt="">
                                            <img src="images/star.png" alt="">
                                            <img src="images/star.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="chart-bg">
                                        <div class="title-box-chart">
                                            <h5>مبيعات المنتجات</h5>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6><b><Strong>1450</Strong></b> ج.م</h6>
                                                <span><small
                                                        style="font-size: 10px; display: block; margin-top: -10px;">إجمالي
                                                        ربح الأسبوع الماضي</small></span>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-4"></div>
                                                    <div class="col-md-4">
                                                        <div>
                                                            <div class="dropdown">
                                                                <button class="btn btn-secondary dropdown-toggle"
                                                                    type="button" id="dropdownMenuButton1"
                                                                    data-bs-toggle="dropdown" aria-expanded="false"
                                                                    style="background-color: rgba(118,185,82,.2); border: none; color: #76B952;">
                                                                    21%
                                                                </button>
                                                                <ul class="dropdown-menu"
                                                                    aria-labelledby="dropdownMenuButton1">
                                                                    <li><a class="dropdown-item" href="#">Action</a>
                                                                    </li>
                                                                    <li><a class="dropdown-item" href="#">Another
                                                                            action</a></li>
                                                                    <li><a class="dropdown-item" href="#">Something
                                                                            else here</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div style="padding-right: 15px;">
                                                            <div class="dropdown">
                                                                <button class="btn btn-secondary dropdown-toggle"
                                                                    type="button" id="dropdownMenuButton1"
                                                                    data-bs-toggle="dropdown" aria-expanded="false"
                                                                    style="background-color: rgba(238,80,79,.2); border: none; color: #EE504F;">
                                                                    42%
                                                                </button>
                                                                <ul class="dropdown-menu"
                                                                    aria-labelledby="dropdownMenuButton1">
                                                                    <li><a class="dropdown-item" href="#">Action</a>
                                                                    </li>
                                                                    <li><a class="dropdown-item" href="#">Another
                                                                            action</a></li>
                                                                    <li><a class="dropdown-item" href="#">Something
                                                                            else here</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <canvas id="myChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="action-play">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="parts-sec-all">

                                        <div class="parts-title-sec">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>القطع المطلوبة</h6>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="show-all-link">
                                                        <span><a href="">مشاهده الكل</a></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div>
                                                        <img src="images/x.png" width="20" alt="">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div>
                                                        <img src="images/x.png" width="20" alt="">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div>
                                                        <img src="images/x.png" width="20" alt="">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div>
                                                        <img src="images/x.png" width="20" alt="">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div>
                                                        <img src="images/x.png" width="20" alt="">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="parts-sec-all">

                                        <div class="parts-title-sec">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>طلبات قيد الانتظار</h6>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="show-all-link">
                                                        <span><a href="">مشاهده الكل</a></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                                <span> <i class="fas fa-credit-card"></i> الدفع عند
                                                                    الاستلام </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div style="text-align: left;">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                                <span> <i class="fas fa-credit-card"></i> الدفع عند
                                                                    الاستلام </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div style="text-align: left;">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                                <span> <i class="fas fa-credit-card"></i> الدفع عند
                                                                    الاستلام </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div style="text-align: left;">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                                <span> <i class="fas fa-credit-card"></i> الدفع عند
                                                                    الاستلام </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div style="text-align: left;">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="parts-contect-sec">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="prod-img-parts">
                                                                <img src="images/product.png" width="100%">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <div class="prod-txts-parts">
                                                                <h6>عنوان الطلب</h6>
                                                                <span> <i class="fas fa-map-marker-alt"></i> مصر
                                                                    القاهرة التوفقية </span>
                                                                <span> <i class="fa fa-clock"></i> الخميس 22 نوفمبر
                                                                </span>
                                                                <span> <i class="fas fa-credit-card"></i> الدفع عند
                                                                    الاستلام </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div style="text-align: left;">
                                                        <img src="images/right.png" width="20" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- ****************************** Right Side ****************************** -->
                    <div class="col-md-4">
                        <div class="right-side">
                            <div class="bg-tarqia">
                                <h6>قم بترقية حسابك الان !</h6>
                                <p>تعرف علي خطط اسعارنا وقم
                                    بتفعيل خطة الأسعار التي تناسبك</p>
                                <button><a href="" data-bs-toggle="modal" data-bs-target="#Terms-Conditions">إشترك
                                        الان</a></button>
                            </div>

                            <div class="activities-per-right-side">
                                <h6>الانشطة</h6>
                                <div class="sub-activ-right-side">
                                    <span style="display: block;">لقد قمت بالتاكيد على طلب <label>احمد
                                            ابراهيم</label> بخصوص قطع غيار</span>
                                    <span class="date-right-side">
                                        <small>الجمعة 20 فبراير 2020</small>
                                    </span>
                                </div>
                                <div class="sub-activ-right-side">
                                    <span style="display: block;">لقد قمت بالتاكيد على طلب <label>احمد
                                            ابراهيم</label> بخصوص قطع غيار</span>
                                    <span class="date-right-side">
                                        <small>الجمعة 20 فبراير 2020</small>
                                    </span>
                                </div>
                                <div class="sub-activ-right-side">
                                    <span style="display: block;">لقد قمت بالتاكيد على طلب <label>احمد
                                            ابراهيم</label> بخصوص قطع غيار</span>
                                    <span class="date-right-side">
                                        <small>الجمعة 20 فبراير 2020</small>
                                    </span>
                                </div>
                            </div>

                            <div class="no-activi text-center">
                                <div class="img-no-activ">
                                    <img src="images/no-activites.png">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ***************************************** -->
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 60% !important;">
        <div class="modal-content" style="background: none; border: none;">
            <div class="modal-body">
                <div class="add-product-form">

                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                                class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                                aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-add-prod-sub">
                                            <div class="fly-self-home">
                                                <h6>أعلن عن منتجك</h6>
                                                <p>
                                                    العنوان المناسب للمنتج: يجب أن يملك الإعلان عن
                                                    منتج عنوان جذاب، وأن يكون الإعلان غير تقليدي ومختلف وجذاب، ويحتوي
                                                    كلمات أو عبارات
                                                    تجذب أنتباه المتلقي. النص الكتابي الهادف: أن يكون النص جديد ومبتكر
                                                    وغير تقليدي،
                                                    وأن يكون مفهوم للجميع وبسيط، وتحديد الفئة العمرية المراد مخاطبتها في
                                                    الإعلان.
                                                </p>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <br> <br>
                                                    <button type="button" style="width: 100%;" class="btn btn-accent"
                                                        data-bs-dismiss="modal">
                                                        تخطي
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"
                                        style="background-image: url(images/model-side.png); height: 550px;">

                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-add-prod-sub">
                                            <div class="fly-self-home">
                                                <h6>أعلن عن منتجك</h6>
                                                <p>
                                                    العنوان المناسب للمنتج: يجب أن يملك الإعلان عن
                                                    منتج عنوان جذاب، وأن يكون الإعلان غير تقليدي ومختلف وجذاب، ويحتوي
                                                    كلمات أو عبارات
                                                    تجذب أنتباه المتلقي. النص الكتابي الهادف: أن يكون النص جديد ومبتكر
                                                    وغير تقليدي،
                                                    وأن يكون مفهوم للجميع وبسيط، وتحديد الفئة العمرية المراد مخاطبتها في
                                                    الإعلان.
                                                </p>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <br> <br>
                                                    <button type="button" style="width: 100%;" class="btn btn-accent"
                                                        data-bs-dismiss="modal">
                                                        تخطي
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"
                                        style="background-image: url(images/model-side.png); height: 550px;">

                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-add-prod-sub">
                                            <div class="fly-self-home">
                                                <h6>أعلن عن منتجك</h6>
                                                <p>
                                                    العنوان المناسب للمنتج: يجب أن يملك الإعلان عن
                                                    منتج عنوان جذاب، وأن يكون الإعلان غير تقليدي ومختلف وجذاب، ويحتوي
                                                    كلمات أو عبارات
                                                    تجذب أنتباه المتلقي. النص الكتابي الهادف: أن يكون النص جديد ومبتكر
                                                    وغير تقليدي،
                                                    وأن يكون مفهوم للجميع وبسيط، وتحديد الفئة العمرية المراد مخاطبتها في
                                                    الإعلان.
                                                </p>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <br> <br>
                                                    <button type="button" style="width: 100%;" class="btn btn-accent"
                                                        data-bs-dismiss="modal">
                                                        تخطي
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"
                                        style="background-image: url(images/model-side.png); height: 550px;">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\original\resources\views/dashboard/index.blade.php ENDPATH**/ ?>